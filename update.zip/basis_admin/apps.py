from django.apps import AppConfig


class BasisAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'basis_admin'
