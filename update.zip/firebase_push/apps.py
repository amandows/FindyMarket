from django.apps import AppConfig


class FirebasePushConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'firebase_push'
