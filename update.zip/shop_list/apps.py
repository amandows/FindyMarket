from django.apps import AppConfig


class ShopListConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shop_list'
