from django.apps import AppConfig


class CreateFoodConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'create_food'
